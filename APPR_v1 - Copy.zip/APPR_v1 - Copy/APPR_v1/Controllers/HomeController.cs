﻿using System.Diagnostics;
using APPR_v1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using Microsoft.CodeAnalysis.Elfie.Model.Tree;
using Microsoft.Identity.Client.Extensions.Msal;
using Microsoft.EntityFrameworkCore;
using APPR_v1.Data;

namespace APPR_v1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Registration()
        {
            return View();
        }

        public IActionResult LogIn()
        {
            return View();
        }

        public IActionResult DonateFunds(Storage storage)
        {
            if (ModelState.IsValid)
            {
                _context.storage.Add(storage);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        public IActionResult DonateGoods()
        {
            return View();
        }
        public IActionResult AllocateFunds()
        {
            return View();
        }
        public IActionResult AllocateGood()
        {
            return View();
        }
        public IActionResult Disaster()
        {
            return View();
        }

        public ActionResult Index1()
        {
            return View();
        }

        public ActionResult DisplayText(string buttonText)
        {
            string textToDisplay = GetTextForButton(buttonText);
            return PartialView("_DisplayTextPartial", textToDisplay);
        }

        private string GetTextForButton(string buttonText)
        {
            switch (buttonText)
            {
                case "Button1":
                    return "Total funds received: R 341500";
                case "Button2":
                    return "Total Goods received: 78"  + "\n" + "Clothing: 67    Non-perishable goods: 11" ;
                case "Button3":
                    return "Number of currently active disasters: 8";
                default:
                    return " ";
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}