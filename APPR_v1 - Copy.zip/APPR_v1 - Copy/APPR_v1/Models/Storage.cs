﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace APPR_v1.Models
{
    public class User
    {
        [Required]
        [Display(Name = "UserName")]
        public String UserName {  get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string EmailAddress { get; set; }

        [Required]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public String Password { get; set; }

        [Required]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public String ConfirmPassword { get; set;}


    }

    public class MonetaryDonation
    {
        [Key]
        [Required]
        [Display(Name = "Date")]
        public int Date { get; set; }

        [Required]
        [Display(Name = "Amount")]
        public int Amount { get; set; }
    }

    public class GoodsDonation
    {
        [Required]
        [Display(Name = "Date")]
        public int Date { get; set; }

        [Required]
        [Display(Name = "Number of items")]
        public int NoOfItem { get; set; }

        [Required]
        [Display(Name = "Item description")]
        public String ItemDescription { get; set; }


    }

    public class Disaster
    {
        [Key]
        [Required]
        [Display(Name = "Start date")]
        public int StartDate { get; set; }
        
        [Required]
        [Display(Name = "End date")]
        public int EndDate { get; set; }

        [Required]
        [Display(Name = "Location")]
        public string Location { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string DisasterName { get; set; }

        //public bool Water;
        //public bool Cloth;
        //public bool Food;
    }

    public class allocateFunds
    {
        [Required]
        [Display(Name = "Amount")]
        public int Amount { get; set; }

        [Required]
        [Display(Name = "Disaster")]
        public String DisasterName { get; set; }
    }

    public class allocateGoods
    {
        [Required]
        [Display(Name = "Items")]
        public String Item { get; set; }

        [Required]
        [Display(Name = "Amount")]
        public String Amount { get; set; }

        [Required]
        [Display(Name = "Disaster")]
        public String DisasterName { get; set; }
    }
}
