﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using APPR_v1.Data;

namespace APPR_v1

{
    public class Startup
    {
        // Configuration property to access appsettings.json
        public IConfiguration Configuration { get; }

        // Constructor to inject IConfiguration
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // ConfigureServices method to configure services
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));



            
        }

        // Configure method to set up the HTTP request pipeline
        public void Configure(IApplicationBuilder app)
        {
            
        }
    }

}
