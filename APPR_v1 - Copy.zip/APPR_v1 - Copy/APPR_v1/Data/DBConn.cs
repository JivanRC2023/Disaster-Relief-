﻿namespace APPR_v1.Data
{
    public class DBConn
    {

    }
}
